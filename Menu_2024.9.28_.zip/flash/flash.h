
/*
 * flash.h
 *
 *  Created on: 2023��4��14��
 *      Author: ֣��
 */
#ifndef CODE_CPU2_MENU_FLASH_FLASH_H_
#define CODE_CPU2_MENU_FLASH_FLASH_H_
#include "zf_common_headfile.h"
#include "mymenu.h"

extern int GPS_num; //GPS������

typedef union                                                                   // �̶������ݻ��嵥Ԫ��ʽ
{
  uint32 uint32_type[2];      //unsigned long long����
  double double_type;      //double����
}Double_union;

typedef enum
{
  data_servo_turn_p = 0,
  data_servo_turn_d = 1,
  data_duty    = 2,
  data_sat_angle    = 3,
  data_gnssmode  =4,
  data_gpsnum   =5,

  data_elementorder =6,
  data_straightpoint =7,
  data_turnpoint     =8,
  data_Spoint        =9,
  data_circlepoint   =10,
  data_backpoint     =11,

  data_straightdistant =12,
  data_turndistant =13,
  data_Sdistant        =14,
  data_circledistant   =15,
  data_backdistant     =16,

  data_servo_straight_p = 17,
  data_servo_straight_d = 18,
}Control_data;


void menu_para_init(void);
void position_store(void);
void position_read(double *GPSPoint_longitude,double *GPSPoint_latitude);
void GPSPoint_store(uint8 Pointnum,double longitude,double latitude);
double GPSPoint_longitude_read(uint8 Pointnum);
double GPSPoint_latitude_read(uint8 Pointnum);
void data_store(Control_data data_num,float data);
void Gps_Save_Point(void);
//void data_read(void);
void Speed_store(uint8 Pointnum,int8 motorspeed);
//void Speed_read(void);
#endif /* CODE_CPU2_MENU_FLASH_FLASH_H_ */
