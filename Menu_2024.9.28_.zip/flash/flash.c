/*
 * flash.c
 *
 *  Created on: 2023��4��14��
 *      Author: ֣��
 */
//��11ҳ��GPS�������
//��10ҳ�����Ʋ���
#include "flash.h"

double RTKPoint_longitude[20]={111,222,333};           //д��GPS��γ������
double RTKPoint_latitude[20]={111,222,333};           //д��GPS��γ������
double actual_distance=1.85;


    //(num-1)*4   longitude L
    //(num-1)*4+1 longitude H
    //(num-1)*4+2 latitude  L
    //(num-1)*4+3 latitude  H
int32 GPS_num=0;

void menu_para_init(void){
//      position_read(&RTKPoint_longitude,&RTKPoint_latitude);//GPS��ȡ
//      data_read();
//      Speed_read();
}

Double_union flash_Double;

void data_store(Control_data data_num,float data){
    flash_read_page_to_buffer(0, 10);
    flash_union_buffer[data_num].float_type=data;
    flash_erase_page(0, 10);
    if(!flash_write_page_from_buffer(0, 10))flash_buffer_clear();
}

//void data_read(void){
//    flash_read_page_to_buffer(0, 10);
//    servo_turn.P         =   flash_union_buffer[data_servo_turn_p].float_type;
//    servo_turn.D         =   flash_union_buffer[data_servo_turn_d].float_type;
//    servo_straight.P         =   flash_union_buffer[data_servo_straight_p].float_type;
//    servo_straight.D         =   flash_union_buffer[data_servo_straight_d].float_type;
//    eskf_angle      =   flash_union_buffer[data_sat_angle].float_type;
//    gnssmode        =   flash_union_buffer[data_gnssmode].float_type;
//    GPS_num         =   flash_union_buffer[data_gpsnum].float_type;
//    elementorder    =   flash_union_buffer[data_elementorder].float_type;
//    straightpoint   =   flash_union_buffer[data_straightpoint].float_type;
//    turnpoint       =   flash_union_buffer[data_turnpoint].float_type;
//    Spoint          =   flash_union_buffer[data_Spoint].float_type;
//    circlepoint     =   flash_union_buffer[data_circlepoint].float_type;
//    backpoint       =   flash_union_buffer[data_backpoint].float_type;
//    straightdistant   =   flash_union_buffer[data_straightdistant].float_type;
//    turndistant       =   flash_union_buffer[data_turndistant].float_type;
//    Sdistant          =   flash_union_buffer[data_Sdistant].float_type;
//    circledistant     =   flash_union_buffer[data_circledistant].float_type;
//    backdistant       =   flash_union_buffer[data_backdistant].float_type;
//    duty=flash_union_buffer[data_duty].float_type;

//}




//��γ�ȴ洢
void position_store(void){
    flash_read_page_to_buffer(0, 11);//��ȡ��ʮһҳ����
    for(uint8 i=0;i<GPS_num;i++){
        //�õ���������
        flash_Double.double_type = RTKPoint_longitude[i];
        //����д�뻺����
        flash_union_buffer[i*4].uint32_type = flash_Double.uint32_type[1];
        flash_union_buffer[i*4+1].uint32_type = flash_Double.uint32_type[0];
        //�õ�γ������
        flash_Double.double_type = RTKPoint_latitude[i];
        //γ��д�뻺����
        flash_union_buffer[i*4+2].uint32_type = flash_Double.uint32_type[1];
        flash_union_buffer[i*4+3].uint32_type = flash_Double.uint32_type[0];
        //��������
        flash_erase_page(0, 11);
        //��д����ջ�����
        flash_write_page_from_buffer(0, 11);
   //if(!flash_write_page_from_buffer(0, 11)) flash_buffer_clear();
    }
}

//��γ�ȶ�ȡ
void position_read(double *GPSPoint_longitude,double *GPSPoint_latitude){
    flash_read_page_to_buffer(0, 11);//��ȡ��ʮһҳ����
    for(uint8 i=0;i<GPS_num;i++){
        //���ȶ�ȡ
        flash_Double.uint32_type[1] = flash_union_buffer[i*4].uint32_type;
        flash_Double.uint32_type[0] = flash_union_buffer[i*4+1].uint32_type;
        GPSPoint_longitude[i] = flash_Double.double_type;
        //γ�ȶ�ȡ
        flash_Double.uint32_type[1] = flash_union_buffer[i*4+2].uint32_type;
        flash_Double.uint32_type[0] = flash_union_buffer[i*4+3].uint32_type;
        GPSPoint_latitude[i] = flash_Double.double_type;

    }
}


//�洢������ľ�γ��
void GPSPoint_store(uint8 Pointnum,double longitude,double latitude){
    flash_read_page_to_buffer(0, 11);//��ȡ��ʮһҳ����

    //ȡ����
    flash_Double.double_type=longitude;
    //�洢���ȵĵ�λ��λ
    flash_union_buffer[(Pointnum-1)*4].uint32_type = flash_Double.uint32_type[1];
    flash_union_buffer[(Pointnum-1)*4+1].uint32_type = flash_Double.uint32_type[0];

    //ȡγ�ȵĵ�λ��λ
    flash_Double.double_type=latitude;
    //�洢γ�ȵĵ�λ��λ
    flash_union_buffer[(Pointnum-1)*4+2].uint32_type = flash_Double.uint32_type[1];
    flash_union_buffer[(Pointnum-1)*4+3].uint32_type = flash_Double.uint32_type[0];

    flash_erase_page(0, 11);
    if(!flash_write_page_from_buffer(0, 11))flash_buffer_clear();
}
//��ȡ������ľ���
double GPSPoint_longitude_read(uint8 Pointnum){
    flash_read_page_to_buffer(0, 11);//��ȡ��ʮһҳ����

    flash_Double.uint32_type[1] = flash_union_buffer[(Pointnum-1)*4].uint32_type;
    flash_Double.uint32_type[0] = flash_union_buffer[(Pointnum-1)*4+1].uint32_type;
    return flash_Double.double_type ;
}
//��ȡ������ľ���
double GPSPoint_latitude_read(uint8 Pointnum){
    flash_read_page_to_buffer(0, 11);//��ȡ��ʮһҳ����
    flash_Double.uint32_type[1] = flash_union_buffer[(Pointnum-1)*4+2].uint32_type;
    flash_Double.uint32_type[0] = flash_union_buffer[(Pointnum-1)*4+3].uint32_type;
    return flash_Double.double_type ;
}

//�洢��������ٶ�
void Speed_store(uint8 Pointnum,int8 motorspeed){
    flash_read_page_to_buffer(0, 9);//��ȡ�ھ�ҳ����

    //�洢�ٶ�
    flash_union_buffer[Pointnum-1].int8_type = motorspeed;      //int8ռһ���ֽ�

    flash_erase_page(0, 9);
    if(!flash_write_page_from_buffer(0, 9))
        flash_buffer_clear();
}

//��ȡÿ������ٶ�
//void Speed_read(void){
//    flash_read_page_to_buffer(0, 9);//��ȡ�ھ�ҳ����
//
//    for(uint8 i=0;i<GPS_num;i++)
//        Point_TargetDuty[i]=flash_union_buffer[i].int8_type;
//
//}
