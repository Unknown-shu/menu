/*
 * Gyro_page.c
 *
 *  Created on: 2023��3��25��
 *      Author: Dell
 */
#include "zf_common_headfile.h"
#include "mymenu.h"

int start_flag = 0;
void start_page_process(int Event_Code)
{
    line_number_max=5;

   //��ʾ�˵�
    ips200_show_string_color(105, 0,"START", PenColor);

    if(line_number!=1)     ips200_show_string_color(0, 18,"gyro_init", PenColor);
     else                  ips200_show_string_color(0, 18,"gyro_init", PenColor_else);
    if(line_number!=2)     ips200_show_string_color(0, 18*2,"wifi_init", PenColor);
     else                  ips200_show_string_color(0, 18*2,"wifi_init", PenColor_else);
    if(line_number!=3)     ips200_show_string_color(0, 18*3,"start_mode", PenColor);
     else                  ips200_show_string_color(0, 18*3,"start_mode", PenColor_else);
    if(line_number!=4)     ips200_show_string_color(0, 18*4,"ENGINE_START", PenColor);
     else                  ips200_show_string_color(0, 18*4,"ENGINE_START", PenColor_else);
    ips200_show_int_color(100, 18*3,FLAG.startmode,1, PenColor);


    if(key_get_state(KEY_1) == KEY_SHORT_PRESS)
    {
        gpio_set_level(Beep,1);
        system_delay_ms(10);
        gpio_set_level(Beep,0);
        key_clear_state(KEY_1);
        line_number--;//����ѡ������
        pagelimit(&line_number,line_number_max);
    }
    if(key_get_state(KEY_3) == KEY_SHORT_PRESS)
    {
        gpio_set_level(Beep,1);
        system_delay_ms(10);
        gpio_set_level(Beep,0);
        key_clear_state(KEY_3);
        line_number++; //����ѡ������
        pagelimit(&line_number,line_number_max);
    }
    if(key_get_state(KEY_2) == KEY_SHORT_PRESS)
    {
        gpio_set_level(Beep,1);
        system_delay_ms(10);
        gpio_set_level(Beep,0);
        key_clear_state(KEY_2);
        Set_Menu(&menu, MAIN_PAGE);
        line_number=1;
        ips200_clear();
    }
    if(key_get_state(KEY_4) == KEY_SHORT_PRESS)
    {
        gpio_set_level(Beep,1);
        system_delay_ms(10);
        gpio_set_level(Beep,0);
        switch(line_number)
        {
            case 1:
                system_delay_ms(1000);
                gyroscope_init();
                break ;
            case 2:
                wifi_init();
                break;
            case 3:
                if(FLAG.startmode)
                    FLAG.startmode = 0;
                else
                    FLAG.startmode = 1;
                ips200_show_int_color(100, 18*3,FLAG.startmode,1, PenColor);
                break;
            case 4:
                start_flag = 1;
                break;
            default:
                break ;
        }
        key_clear_state(KEY_4);
    }

}


