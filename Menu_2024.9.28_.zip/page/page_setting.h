/*
 * page_setting.h
 *
 *  Created on: 2023��3��5��
 *      Author: ֣��
 */
#include "zf_common_headfile.h"
#include "mymenu.h"
#ifndef CODE_MENU_PAGE_SETTING_H_
#define CODE_MENU_PAGE_SETTING_H_



extern int8 line_number;
extern uint8 line_number_max;

extern int8 row_number;
extern uint8 row_number_max;

extern float increment1[4];
extern float increment2[4];
extern float increment3[3];
extern float mtspeedlevel[5];

void main_page_process(int Event_Code);
void start_page_process(int Event_Code);
void image_page_process(int Event_Code);
void rtk_page_process(int Event_Code);
void setpoint(struct Menu *handle);
void Key_Event(void);

#endif /* CODE_MENU_PAGE_SETTING_H_ */
